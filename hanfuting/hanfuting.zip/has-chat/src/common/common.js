export default {
  // 是否登陆
  isLogin() {
    return window.localStorage.getItem("token") ? true : false;
  },
// 返回首页
  toHome() {
     home(data.form).then((res) => {
      if (res?.code == 200) {
      store.initSetInfo(res?.data);
      // 重定向到同目录下的 main.html 文件
      window.location.href = "../../hanfuting/main.html";
    } else {
      if (messageBox != undefined) {
        messageBox.error(res?.message);
      }
    }
  });
}
}